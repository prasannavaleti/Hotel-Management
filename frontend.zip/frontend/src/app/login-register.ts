export class LoginRegister {
    constructor(
        public statusCode: number,
        public message: string,
        public description: string,
        public type: string
    ) {
    }
}
